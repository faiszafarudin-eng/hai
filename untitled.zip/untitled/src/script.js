const text = "Hai sayang, happy anniversary first year ya sayang!😻, ga nyangka uda 1 tahun aja🤭, makasi uda mau bertahan+ga milih yang lain. Maaf kalo aku banyak salah ke kamu, sering bikin kamu bm, marah, bentak² kamu, suka maksa², dan masi banyak lagi😞. Tapi aku beneran sayang banget sama kamu tau, meskipun kamu sering kecewain aku tapi gapapa, karna kamu ga ada gantinya lagi. Aku masih inget sepinya hidupku sebelum ada kamu, dulu aku mau ngungkapin ke kamu tapi masih takut, dan akhirnya kamu chat+aku nyatain perasaanku dan makasi banyak uda nerima aku ya sayang, aku seneng banget😻. Sayang, kamu itu cantik banget, lucu, baik, pinter, gemesin, dan wanginya itu ga ada kembarannya, wangi banget gitu🤭. Dulu asik banget ya pas awal-awal kita kenalan, mastiin² serius atau engga. Meskipun banyak berantemnya tapi jangan sampe cari kenyamanan di orang lain ya!. Umm itu doang mungkin yang bisa aku ucapin, oh iya, tunggu aku sekitar 10 tahun lagi okey, makasi sayang. Maaf kalo ga jelas, soalnya yang jelas cintaku ke kamu itu hehe, I LOVE YOU FOREVER SAYANGG!!!!!🤍🤍🤍";

let i = 0;

function typing() {

  if (i < text.length) {

    document.getElementById("typing-text").innerHTML += text.charAt(i);

    i++;

    setTimeout(typing, 50); // efek ketik 50ms

  }

}

window.onload = typing;